# orchestrator

A single web page [index.html](./index.html) that uses the [Vaadin Router](https://vaadin.com/router) to load 
different micro frontends.  

It is part of `micro-frontends-demo`; see the [main README](../README.md) for details about the entire project and how 
to run it. There is no build step for this app.

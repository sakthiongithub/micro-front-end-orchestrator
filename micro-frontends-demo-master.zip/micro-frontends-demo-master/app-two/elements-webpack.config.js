module.exports = {
  output: {
    jsonpFunction: 'webpackJsonpAppTwo',
    library: 'apptwo'
  }
};

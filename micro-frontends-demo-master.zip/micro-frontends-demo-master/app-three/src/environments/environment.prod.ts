export const environment = {
  production: true,
  serviceUrl: 'http://127.0.0.1:8080'
};
